Talk of the Town POS -- Windows Desktop Client
=================================================
System: Road Not Taken Enterprise Restaurant POS & ERP

QUICK LAUNCH:
Double-click 'Launch-POS.bat' to launch the standalone desktop POS application.

KEYBOARD SHORTCUTS:
- [F1] : Cashier POS
- [F2] : Customer Self-Ordering Kiosk
- [F3] : Floor & Split Bill Table Management
- [F4] : Kitchen KDS
- [F5] : Trigger Edge Sync
- [F6] : Recipe BOM & 144 Master Stock
- [F7] : PO & GRN Inwarding
- [F8] : Staff & Salary Payroll
- [F9] : Cash Shift & Z-Report
- [F10]: Rule Book & SOP Checklists
- [F11]: Toggle Fullscreen Kiosk Mode
- [Ctrl+P]: Print ESC/POS Thermal Receipt

DUAL-MONITOR CUSTOMER DISPLAY (CFD):
To enable the customer-facing secondary monitor, plug your HDMI/USB display into your PC and set display to 'Extend'. The POS detects the secondary screen and renders the interactive customer invoice and UPI QR display.
