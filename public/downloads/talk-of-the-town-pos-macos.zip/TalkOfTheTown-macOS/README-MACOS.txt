Talk of the Town POS -- macOS Desktop Client
=================================================
System: Road Not Taken Enterprise Restaurant POS & ERP

INSTALLATION ON macOS:
1. Extract 'TalkOfTheTown.app' into your Applications folder.
2. If macOS Gatekeeper displays 'Unidentified Developer', right-click 'TalkOfTheTown.app' and select 'Open'.
3. The app will open in native fullscreen desktop mode with hardware printer spooling and offline SQLite storage.

KEYBOARD SHORTCUTS:
- [F1] or [Cmd+1] : Cashier POS
- [F2] or [Cmd+2] : Customer Self-Ordering Kiosk
- [F3] or [Cmd+3] : Floor & Split Bill Table Management
- [F4] or [Cmd+4] : Kitchen KDS
- [F5] : Trigger Edge Sync
- [Cmd+P] : Thermal Receipt Print
- [F11] : Fullscreen
